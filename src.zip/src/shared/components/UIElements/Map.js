import React, { useRef, useEffect } from "react";

import './Map.css'

const Map = props => {
  const mapRef = useRef();

  const { center, zoom } = props;
  // const [center, zoom] = [props.center, props.zoom];
  // const { center, zoom } = { center: props.center, zoom: props.zoom };


  useEffect(() => {
    const map = new window.SVGFEMorphologyElement.maps.Map(mapRef.current, {
      center: center,
      zoom: zoom
    });

    new window.SVGFEMorphologyElement.maps.Marker(
      {
        position: props.center,
        map: map
      }
    );
  }, [center, zoom])

  return (
    <div ref={mapRef}
      className={`map 
      ${props.className} 
      style={props.style}`}
    ></div>
  );
}
export default Map;


